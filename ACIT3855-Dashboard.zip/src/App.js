import './App.css'
import Stats from './components/Stats'

const App = () => {
  return (
    <div className="App">
      <h1>Dashboard</h1>
      <Stats />
    </div>
  );
}

export default App
